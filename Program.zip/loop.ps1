$i = 21600
do {
    Write-Host $i
    Sleep 1s
    echo haiii brooo
    $i--
} while ($i -gt 0)